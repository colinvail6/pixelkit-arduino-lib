#include "PixelKit.h"

// ---------------------- Constructor ----------------------
PixelKit::PixelKit(uint8_t pin, uint8_t width, uint8_t height, int micThreshold)
    : _pin(pin), _width(width), _height(height),
      _pixels(nullptr), _serpentine(false),
      _buttonAPin(23), _buttonBPin(18), _buttonResetPin(5),
      _joystickUpPin(35), _joystickDownPin(34), _joystickLeftPin(26), _joystickRightPin(25), _joystickClickPin(27),
      _dialPin(36), _micPin(39), _buzzerPin(22),
      _lastButtonAState(HIGH), _lastButtonBState(HIGH), _lastButtonResetState(HIGH),
      _lastJoyUpState(HIGH), _lastJoyDownState(HIGH), _lastJoyLeftState(HIGH), _lastJoyRightState(HIGH), _lastJoyClickState(HIGH),
      _lastButtonATime(0), _lastButtonBTime(0), _lastButtonResetTime(0),
      _lastJoyUpTime(0), _lastJoyDownTime(0), _lastJoyLeftTime(0), _lastJoyRightTime(0), _lastJoyClickTime(0),
      _lastDialValue(-1), _lastMicValue(-1), _currentDialValue(0), _currentMicValue(0),
      _micThreshold(micThreshold),
      _dialSmoothingEnabled(false), _dialSmoothedValue(0), _dialSmoothingFactor(0.1f),
      _micSmoothingEnabled(false), _micSmoothedValue(0), _micSmoothingFactor(0.1f),
      _cbButtonA(nullptr), _cbButtonB(nullptr), _cbButtonReset(nullptr),
      _cbJoyUp(nullptr), _cbJoyDown(nullptr), _cbJoyLeft(nullptr), _cbJoyRight(nullptr), _cbJoyClick(nullptr),
      _cbDialChange(nullptr), _cbMicChange(nullptr),
      _cbBeepStart(nullptr), _cbBeepEnd(nullptr),
      _cbMelodyStart(nullptr), _cbMelodyEnd(nullptr), _cbMelodyNote(nullptr),
      _beepActive(false), _beepStartMillis(0), _beepDurationMillis(0), _beepFreq(0),
      _melodyNotes(nullptr), _melodyDurations(nullptr), _melodyLength(0), _melodyIndex(0), _melodyPlaying(false), _melodyNoteStartMillis(0)
{
}

// ---------------------- Begin ----------------------
void PixelKit::begin() {
    if (!_pixels) {
        _pixels = new Adafruit_NeoPixel(_width * _height, _pin, NEO_GRB + NEO_KHZ800);
        _pixels->begin();
        _pixels->show();
    }

    // Buttons / joystick as pullups
    pinMode(_buttonAPin, INPUT_PULLUP);
    pinMode(_buttonBPin, INPUT_PULLUP);
    pinMode(_buttonResetPin, INPUT_PULLUP);
    pinMode(_joystickUpPin, INPUT_PULLUP);
    pinMode(_joystickDownPin, INPUT_PULLUP);
    pinMode(_joystickLeftPin, INPUT_PULLUP);
    pinMode(_joystickRightPin, INPUT_PULLUP);
    pinMode(_joystickClickPin, INPUT_PULLUP);

    // Analog inputs
    pinMode(_dialPin, INPUT);
    pinMode(_micPin, INPUT);

    pinMode(_buzzerPin, OUTPUT);

    _lastDialValue = analogRead(_dialPin);
    _lastMicValue = analogRead(_micPin);
    _currentDialValue = _lastDialValue;
    _currentMicValue = _lastMicValue;
}

// ---------------------- Pixels ----------------------
uint32_t PixelKit::Color(uint8_t r, uint8_t g, uint8_t b) { return Adafruit_NeoPixel::Color(r, g, b); }
void PixelKit::setBrightness(uint8_t brightness) { if (_pixels) _pixels->setBrightness(brightness); }
void PixelKit::setSerpentine(bool enabled) { _serpentine = enabled; }
int PixelKit::_mapXYtoIndex(uint8_t x, uint8_t y) { return _serpentine && (y % 2) ? y * _width + (_width - 1 - x) : y * _width + x; }
void PixelKit::setPixel(uint8_t x, uint8_t y, uint32_t color) { if (_pixels) _pixels->setPixelColor(_mapXYtoIndex(x, y), color); }
void PixelKit::setPixelColor(uint8_t x, uint8_t y, uint8_t r, uint8_t g, uint8_t b) { setPixel(x, y, Color(r, g, b)); }
void PixelKit::fill(uint32_t color) { if (_pixels) for (int i = 0; i < _width * _height; i++) _pixels->setPixelColor(i, color); }
void PixelKit::clear() { fill(Color(0, 0, 0)); }
void PixelKit::render() { if (_pixels) _pixels->show(); }
uint8_t PixelKit::width() { return _width; }
uint8_t PixelKit::height() { return _height; }

// ---------------------- Callbacks ----------------------
void PixelKit::onButtonA(std::function<void()> cb) { _cbButtonA = cb; }
void PixelKit::onButtonB(std::function<void()> cb) { _cbButtonB = cb; }
void PixelKit::onButtonReset(std::function<void()> cb) { _cbButtonReset = cb; }
void PixelKit::onJoystickUp(std::function<void()> cb) { _cbJoyUp = cb; }
void PixelKit::onJoystickDown(std::function<void()> cb) { _cbJoyDown = cb; }
void PixelKit::onJoystickLeft(std::function<void()> cb) { _cbJoyLeft = cb; }
void PixelKit::onJoystickRight(std::function<void()> cb) { _cbJoyRight = cb; }
void PixelKit::onJoystickClick(std::function<void()> cb) { _cbJoyClick = cb; }
void PixelKit::onDialChange(std::function<void(int)> cb) { _cbDialChange = cb; }
void PixelKit::onMicChange(std::function<void(int)> cb) { _cbMicChange = cb; }
void PixelKit::onBeepStart(std::function<void()> cb) { _cbBeepStart = cb; }
void PixelKit::onBeepEnd(std::function<void()> cb) { _cbBeepEnd = cb; }
void PixelKit::onMelodyStart(std::function<void()> cb) { _cbMelodyStart = cb; }
void PixelKit::onMelodyEnd(std::function<void()> cb) { _cbMelodyEnd = cb; }
void PixelKit::onMelodyNote(std::function<void(int, unsigned long)> cb) { _cbMelodyNote = cb; }
void PixelKit::setMicThreshold(int threshold) { _micThreshold = threshold; }
int PixelKit::getMicThreshold() const { return _micThreshold; }

// ---------------------- Smoothing ----------------------
void PixelKit::enableSmoothing(AnalogComponent comp, float factor) {
    if (factor <= 0.0f) factor = 0.1f;
    if (factor > 1.0f) factor = 1.0f;
    if (comp == Dial) { _dialSmoothingEnabled = true; _dialSmoothingFactor = factor; _dialSmoothedValue = _currentDialValue; }
    else if (comp == Mic) { _micSmoothingEnabled = true; _micSmoothingFactor = factor; _micSmoothedValue = _currentMicValue; }
}
void PixelKit::disableSmoothing(AnalogComponent comp) { if (comp == Dial) _dialSmoothingEnabled = false; else if (comp == Mic) _micSmoothingEnabled = false; }
int PixelKit::readDial() const { return _dialSmoothingEnabled ? (int)_dialSmoothedValue : _currentDialValue; }
int PixelKit::readMic() const { return _micSmoothingEnabled ? (int)_micSmoothedValue : _currentMicValue; }

// ---------------------- Buzzer ----------------------
void PixelKit::beep(unsigned int freq, unsigned long duration) {
    if (_beepActive) { noTone(_buzzerPin); _beepActive = false; if (_cbBeepEnd) _cbBeepEnd(); }
    if (freq == 0 || duration == 0) { noTone(_buzzerPin); _beepActive = false; return; }
    tone(_buzzerPin, freq);
    _beepActive = true; _beepFreq = freq; _beepStartMillis = millis(); _beepDurationMillis = duration;
    if (_cbBeepStart) _cbBeepStart();
}
void PixelKit::playMelody(const unsigned int *melody, const unsigned long *durations, size_t length) {
    if (length == 0 || !melody || !durations) return;
    if (_beepActive) { noTone(_buzzerPin); _beepActive = false; if (_cbBeepEnd) _cbBeepEnd(); }
    _melodyNotes = melody; _melodyDurations = durations; _melodyLength = length; _melodyIndex = 0; _melodyPlaying = true;
    if (_cbMelodyStart) _cbMelodyStart();
    tone(_buzzerPin, _melodyNotes[0]); _melodyNoteStartMillis = millis();
    if (_cbMelodyNote) _cbMelodyNote(_melodyNotes[0], _melodyDurations[0]);
}

// ---------------------- Main loop ----------------------
void PixelKit::checkControls() {
    unsigned long now = millis();

    auto checkBtn = [&](uint8_t pin, bool &lastState, unsigned long &lastTime, std::function<void()> &cb) {
        bool cur = digitalRead(pin);
        if (cur != lastState && now - lastTime >= DEBOUNCE_MS) {
            if (cur == LOW && lastState == HIGH) if (cb) cb();
            lastState = cur; lastTime = now;
        }
    };

    checkBtn(_buttonAPin, _lastButtonAState, _lastButtonATime, _cbButtonA);
    checkBtn(_buttonBPin, _lastButtonBState, _lastButtonBTime, _cbButtonB);
    checkBtn(_buttonResetPin, _lastButtonResetState, _lastButtonResetTime, _cbButtonReset);
    checkBtn(_joystickUpPin, _lastJoyUpState, _lastJoyUpTime, _cbJoyUp);
    checkBtn(_joystickDownPin, _lastJoyDownState, _lastJoyDownTime, _cbJoyDown);
    checkBtn(_joystickLeftPin, _lastJoyLeftState, _lastJoyLeftTime, _cbJoyLeft);
    checkBtn(_joystickRightPin, _lastJoyRightState, _lastJoyRightTime, _cbJoyRight);
    checkBtn(_joystickClickPin, _lastJoyClickState, _lastJoyClickTime, _cbJoyClick);

    // --- Dial ---
    _currentDialValue = analogRead(_dialPin);
    if (_dialSmoothingEnabled) _dialSmoothedValue = _dialSmoothedValue * (1.0f - _dialSmoothingFactor) + _currentDialValue * _dialSmoothingFactor;
    else _dialSmoothedValue = _currentDialValue;
    if (_currentDialValue != _lastDialValue && _cbDialChange) _cbDialChange(_currentDialValue);
    _lastDialValue = _currentDialValue;

    // --- Mic ---
    _currentMicValue = analogRead(_micPin);
    if (_micSmoothingEnabled) _micSmoothedValue = _micSmoothedValue * (1.0f - _micSmoothingFactor) + _currentMicValue * _micSmoothingFactor;
    else _micSmoothedValue = _currentMicValue;
    if (_lastMicValue == -1) _lastMicValue = _currentMicValue;
    int diff = abs(_currentMicValue - _lastMicValue);
    if (diff > _micThreshold && _cbMicChange) _cbMicChange(_currentMicValue);
    if (diff > _micThreshold) _lastMicValue = _currentMicValue;

    // --- Buzzer end ---
    if (_beepActive && now - _beepStartMillis >= _beepDurationMillis) { noTone(_buzzerPin); _beepActive = false; if (_cbBeepEnd) _cbBeepEnd(); }

    // --- Melody playback ---
    if (_melodyPlaying) {
        unsigned long elapsed = now - _melodyNoteStartMillis;
        if (elapsed >= _melodyDurations[_melodyIndex]) {
            _melodyIndex++;
            if (_melodyIndex >= _melodyLength) {
                _melodyPlaying = false; noTone(_buzzerPin); if (_cbMelodyEnd) _cbMelodyEnd();
            } else {
                tone(_buzzerPin, _melodyNotes[_melodyIndex]);
                _melodyNoteStartMillis = now;
                if (_cbMelodyNote) _cbMelodyNote(_melodyNotes[_melodyIndex], _melodyDurations[_melodyIndex]);
            }
        }
    }
}

