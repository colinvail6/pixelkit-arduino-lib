#ifndef PIXELKIT_H
#define PIXELKIT_H

#include <Arduino.h>
#include <Adafruit_NeoPixel.h>
#include <functional>

#define DEBOUNCE_MS 30

class PixelKit {
public:
    enum AnalogComponent {
        Dial,
        Mic
    };

    PixelKit(uint8_t pin = 4, uint8_t width = 16, uint8_t height = 8, int micThreshold = 50);

    void begin();

    // Pixel methods
    uint32_t Color(uint8_t r, uint8_t g, uint8_t b);
    void setBrightness(uint8_t brightness);
    void setSerpentine(bool enabled);
    void setPixel(uint8_t x, uint8_t y, uint32_t color);
    void setPixelColor(uint8_t x, uint8_t y, uint8_t r, uint8_t g, uint8_t b);
    void fill(uint32_t color);
    void clear();
    void render();
    uint8_t width();
    uint8_t height();

    // Event loop
    void checkControls();

    // Callbacks
    void onButtonA(std::function<void()> cb);
    void onButtonB(std::function<void()> cb);
    void onButtonReset(std::function<void()> cb);
    void onJoystickUp(std::function<void()> cb);
    void onJoystickDown(std::function<void()> cb);
    void onJoystickLeft(std::function<void()> cb);
    void onJoystickRight(std::function<void()> cb);
    void onJoystickClick(std::function<void()> cb);
    void onDialChange(std::function<void(int)> cb);
    void onMicChange(std::function<void(int)> cb);
    void onBeepStart(std::function<void()> cb);
    void onBeepEnd(std::function<void()> cb);
    void onMelodyStart(std::function<void()> cb);
    void onMelodyEnd(std::function<void()> cb);
    void onMelodyNote(std::function<void(int, unsigned long)> cb);

    void setMicThreshold(int threshold);
    int getMicThreshold() const;

    // Non-blocking buzzer
    void beep(unsigned int freq, unsigned long duration);
    void playMelody(const unsigned int *melody, const unsigned long *durations, size_t length);

    // Smoothing
    void enableSmoothing(AnalogComponent comp, float factor = 0.1f);
    void disableSmoothing(AnalogComponent comp);

    // Access smoothed/raw values
    int readDial() const;
    int readMic() const;

private:
    uint8_t _pin, _width, _height;
    Adafruit_NeoPixel *_pixels;
    bool _serpentine;

    // Pins
    uint8_t _buttonAPin, _buttonBPin, _buttonResetPin;
    uint8_t _joystickUpPin, _joystickDownPin, _joystickLeftPin, _joystickRightPin, _joystickClickPin;
    uint8_t _dialPin, _micPin, _buzzerPin;

    // Last states for debounce
    bool _lastButtonAState, _lastButtonBState, _lastButtonResetState;
    bool _lastJoyUpState, _lastJoyDownState, _lastJoyLeftState, _lastJoyRightState, _lastJoyClickState;
    unsigned long _lastButtonATime, _lastButtonBTime, _lastButtonResetTime;
    unsigned long _lastJoyUpTime, _lastJoyDownTime, _lastJoyLeftTime, _lastJoyRightTime, _lastJoyClickTime;

    // Analog values
    int _lastDialValue, _lastMicValue;
    int _currentDialValue, _currentMicValue;
    int _micThreshold;

    bool _dialSmoothingEnabled;
    float _dialSmoothedValue;
    float _dialSmoothingFactor;

    bool _micSmoothingEnabled;
    float _micSmoothedValue;
    float _micSmoothingFactor;

    // Callbacks
    std::function<void()> _cbButtonA, _cbButtonB, _cbButtonReset;
    std::function<void()> _cbJoyUp, _cbJoyDown, _cbJoyLeft, _cbJoyRight, _cbJoyClick;
    std::function<void(int)> _cbDialChange, _cbMicChange;
    std::function<void()> _cbBeepStart, _cbBeepEnd;
    std::function<void()> _cbMelodyStart, _cbMelodyEnd;
    std::function<void(int, unsigned long)> _cbMelodyNote;

    // Buzzer
    bool _beepActive;
    unsigned long _beepStartMillis, _beepDurationMillis;
    unsigned int _beepFreq;

    const unsigned int *_melodyNotes;
    const unsigned long *_melodyDurations;
    size_t _melodyLength;
    size_t _melodyIndex;
    bool _melodyPlaying;
    unsigned long _melodyNoteStartMillis;

    int _mapXYtoIndex(uint8_t x, uint8_t y);
};

#endif


