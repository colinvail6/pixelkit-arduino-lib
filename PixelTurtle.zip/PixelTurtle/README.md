# PixelTurtle

PixelTurtle is a turtle graphics add-on for [PixelKit](https://hackster.io/yourproject).  
It provides commands like `forward()`, `left()`, `right()`, `penDown()`, and `setColor()` to draw shapes and animations on a 16×8 NeoPixel grid powered by ESP32.

## Example
```cpp
#include <PixelKit.h>
#include <PixelTurtle.h>

PixelKit kit;
PixelTurtle turtle(kit);

void setup() {
  kit.begin();
  turtle.setColor(0,10,0);
  turtle.moveTo(8,4);

  for(int i=0;i<4;i++){
    turtle.forward(4);
    turtle.right(2); // 90°
  }
}
void loop(){}
```
