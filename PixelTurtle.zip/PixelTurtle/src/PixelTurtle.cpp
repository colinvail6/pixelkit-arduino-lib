#include "PixelTurtle.h"

const int PixelTurtle::headings[8][2] = {
  {0,-1}, {1,-1}, {1,0}, {1,1}, {0,1}, {-1,1}, {-1,0}, {-1,-1}
};

PixelTurtle::PixelTurtle(PixelKit &kit)
: _kit(kit), cursorX(8), cursorY(4),
  colorR(0), colorG(10), colorB(0),
  headingColorR(3), headingColorG(3), headingColorB(0),
  heading(0),
  pixelVisible(true), pixelHeadingVisible(true), pixelPenDown(true) {}

uint32_t PixelTurtle::color(uint8_t r, uint8_t g, uint8_t b) {
  return PixelKit::Color(r,g,b);
}

void PixelTurtle::setColor(uint32_t color) {
    colorR = (color >> 16) & 0xFF;
    colorG = (color >> 8) & 0xFF;
    colorB = color & 0xFF;
    render();
}

void PixelTurtle::setHeadingColor(uint32_t color) {
    headingColorR = (color >> 16) & 0xFF;
    headingColorG = (color >> 8) & 0xFF;
    headingColorB = color & 0xFF;
    render();
}

void PixelTurtle::home() {
    cursorX = 8;   // default center X
    cursorY = 4;   // default center Y
    if (pixelPenDown) stamp();  // optionally stamp at home
    render();                   // update the display
}

void PixelTurtle::moveTo(int x, int y) {
  cursorX = x; cursorY = y;
  if(pixelPenDown) stamp();
  render();
}

void PixelTurtle::move(int dx, int dy) {
  cursorX += dx; cursorY += dy;
  if(pixelPenDown) stamp();
  render();
}

void PixelTurtle::forward(int n) {
  for(int i=0;i<n;i++) {
    if(pixelPenDown) stamp();
    cursorX += headings[heading][0];
    cursorY += headings[heading][1];
  }
  if(pixelPenDown) stamp();
  render();
}

void PixelTurtle::backward(int n) {
  for(int i=0;i<n;i++) {
    if(pixelPenDown) stamp();
    cursorX -= headings[heading][0];
    cursorY -= headings[heading][1];
  }
  if(pixelPenDown) stamp();
  render();
}

void PixelTurtle::left(int n) {
  heading = (heading - n + 8) % 8;
  render();
}

void PixelTurtle::right(int n) {
  heading = (heading + n) % 8;
  render();
}

void PixelTurtle::penDown() { pixelPenDown = true; }
void PixelTurtle::penUp()   { pixelPenDown = false; }

void PixelTurtle::showPixel() { pixelVisible = true; render(); }
void PixelTurtle::hidePixel() { pixelVisible = false; render(); }
void PixelTurtle::showHeading() { pixelHeadingVisible = true; render(); }
void PixelTurtle::hideHeading() { pixelHeadingVisible = false; render(); }
void PixelTurtle::drawPixel() {
    stamp();  // call the private method
}

void PixelTurtle::clear() {
  _kit.fill(color(0,0,0));
  _kit.render();
}

void PixelTurtle::stamp() {
  if(cursorX>=0 && cursorX<16 && cursorY>=0 && cursorY<8)
    _kit.setPixel(cursorX, cursorY, color(colorR,colorG,colorB));
}

void PixelTurtle::renderStage() {
  // stage is implicit: we only draw by stamping directly into kit
}

void PixelTurtle::renderPixel() {
  if(pixelVisible && cursorX>=0 && cursorX<16 && cursorY>=0 && cursorY<8)
    _kit.setPixel(cursorX, cursorY, color(colorR,colorG,colorB));
}

void PixelTurtle::renderHeading() {
  int nx = cursorX + headings[heading][0];
  int ny = cursorY + headings[heading][1];
  if(pixelHeadingVisible && nx>=0 && nx<16 && ny>=0 && ny<8)
    _kit.setPixel(nx, ny, color(headingColorR,headingColorG,headingColorB));
}

void PixelTurtle::render() {
  _kit.fill(color(0,0,0));
  renderPixel();
  renderHeading();
  _kit.render();
}
