#ifndef PIXELTURTLE_H
#define PIXELTURTLE_H

#include <Arduino.h>
#include <PixelKit.h>

class PixelTurtle {
public:
    PixelTurtle(PixelKit &kit);

    void setColor(uint32_t color);          // Accept a single 32-bit color
    void setHeadingColor(uint32_t color);   // Accept a single 32-bit color

    void moveTo(int x, int y);
    void move(int dx, int dy);
    void forward(int n=1);
    void backward(int n=1);
    void home();  // Move cursor to default center

    void left(int n=1);
    void right(int n=1);

    void penDown();
    void penUp();

    void showPixel();
    void hidePixel();
    void drawPixel();  // Public wrapper for stamp()
    void showHeading();
    void hideHeading();

    void clear();

    void render();

private:
    PixelKit &_kit;
    int cursorX, cursorY;
    uint8_t colorR, colorG, colorB;
    uint8_t headingColorR, headingColorG, headingColorB;
    int heading; // index into headings
    bool pixelVisible, pixelHeadingVisible, pixelPenDown;

    static const int headings[8][2]; // direction vectors
    uint32_t color(uint8_t r, uint8_t g, uint8_t b);
    void stamp();
    void renderStage();
    void renderPixel();
    void renderHeading();
};

#endif
